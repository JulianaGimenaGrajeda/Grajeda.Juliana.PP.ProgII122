/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import java.util.ArrayList;

/**
 *
 * @author vocal
 */
public class Jardin{
    private ArrayList<Planta> plantas;

    public Jardin(ArrayList<Planta> plantas) {
        this.plantas = plantas;
    }
    
    public void agregarPlanta(Planta planta){
        plantas.add(planta);
        System.out.println("Planta Agregada con Éxito.. ");
    }
    
   public void podarPlantas(){
      
   }
    
   
}
