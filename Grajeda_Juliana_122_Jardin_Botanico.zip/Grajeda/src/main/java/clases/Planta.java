/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import java.util.ArrayList;

/**
 *
 * @author vocal
 */
public abstract class Planta extends Jardin{
    private final String nombre;
    private final String ubicacionJardin;
    private final  Temporada temporadaFlorecimiento;

    public Planta(String nombre, String ubicacionJardin, Temporada temporadaFlorecimiento, ArrayList<Planta> plantas) {
        super(plantas);
        this.nombre = nombre;
        this.ubicacionJardin = ubicacionJardin;
        this.temporadaFlorecimiento = temporadaFlorecimiento;
    }

    
    
    abstract void podar();

    abstract void desprenderAroma();
    
}
