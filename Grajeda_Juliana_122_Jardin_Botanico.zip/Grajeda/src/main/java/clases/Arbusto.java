package clases;

import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author vocal
 */
public class Arbusto extends Planta{
    private final String densidad;

    public Arbusto(String densidad, String nombre, String ubicacionJardin, Temporada temporadaFlorecimiento, ArrayList<Planta> plantas) {
        super(nombre, ubicacionJardin, temporadaFlorecimiento, plantas);
        this.densidad = densidad;
    }

    @Override
    void podar() {
        System.out.println("Se ha podado el Arbusto");
    }

    @Override
    public String toString() {
        return "Arbusto{" + "densidad=" + densidad + '}';
    }
}