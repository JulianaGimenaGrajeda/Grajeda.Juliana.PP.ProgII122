/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import java.util.ArrayList;

/**
 *
 * @author vocal
 */
public class Flor extends Planta{

    public Flor(String nombre, String ubicacionJardin, Temporada temporadaFlorecimiento, ArrayList<Planta> plantas) {
        super(nombre, ubicacionJardin, temporadaFlorecimiento, plantas);
    }

    @Override
    void desprenderAroma() {
        System.out.println("Desprendiendo Aroma");
    }

    @Override
    public String toString() {
        return "Flor{" + '}';
    }
    
}
