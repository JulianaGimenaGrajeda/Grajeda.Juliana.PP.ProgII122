package clases;

import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author vocal
 */
public class Arbol extends Planta{
    private final int alturaMaxima;

    public Arbol(int alturaMaxima, String nombre, String ubicacionJardin, Temporada temporadaFlorecimiento, ArrayList<Planta> plantas) {
        super(nombre, ubicacionJardin, temporadaFlorecimiento, plantas);
        this.alturaMaxima = alturaMaxima;
    }
    
    @Override
    public void podar(){
        System.out.println("Se ha podado la planta");
    }
    
    @Override
    public void desprenderAroma(){
        System.out.println("Desprendiendo Aroma");
    }

    @Override
    public String toString() {
        return "Arbol{" + "alturaMaxima=" + alturaMaxima + '}';
    }
    
}
